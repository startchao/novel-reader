// app.js — 書卷主程式
'use strict';

// ── STATE ──
const App = {
  currentBookId: null,
  rawText: '',
  displayText: '',
  paragraphs: [],
  chapters: [],
  isConverted: false,
  settings: { fontSize: 18, lineHeight: 2, font: 'serif', theme: 'day' },
};

// ── INIT ──
async function init() {
  await loadSettings();
  applySettings();
  await renderLibrary();
  registerSW();
  setupFileInput();
}

// ── SERVICE WORKER ──
function registerSW() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(()=>{});
  }
}

// ── SETTINGS ──
async function loadSettings() {
  const s = await getSetting('appSettings', null);
  if (s) App.settings = { ...App.settings, ...s };
}

async function persistSettings() {
  await saveSetting('appSettings', App.settings);
}

function applySettings() {
  document.body.setAttribute('data-theme', App.settings.theme);
  const rc = document.getElementById('reader-content');
  if (rc) {
    rc.style.fontSize = App.settings.fontSize + 'px';
    rc.style.lineHeight = App.settings.lineHeight;
    rc.style.fontFamily = App.settings.font === 'sans'
      ? "'Noto Sans TC', sans-serif"
      : "'Noto Serif TC', serif";
  }
  // Sync UI controls
  document.querySelectorAll('[data-theme-btn]').forEach(b =>
    b.classList.toggle('active', b.dataset.themeBtn === App.settings.theme));
  document.querySelectorAll('[data-font-btn]').forEach(b =>
    b.classList.toggle('active', b.dataset.fontBtn === App.settings.font));
  document.getElementById('font-size-val').textContent = App.settings.fontSize;
}

// ── LIBRARY ──
async function renderLibrary() {
  const books = await getAllBooks();
  const grid = document.getElementById('book-grid');
  grid.innerHTML = '';

  // Add upload card first
  const uploadCard = document.createElement('div');
  uploadCard.className = 'upload-card';
  uploadCard.onclick = () => document.getElementById('file-input').click();
  uploadCard.innerHTML = `<div class="upload-icon">📄</div><div class="upload-label">匯入 TXT 小說</div>`;
  grid.appendChild(uploadCard);

  if (books.length === 0) {
    const empty = document.getElementById('empty-library');
    if (empty) empty.style.display = 'flex';
    return;
  }
  const empty = document.getElementById('empty-library');
  if (empty) empty.style.display = 'none';

  books.forEach(book => {
    const card = document.createElement('div');
    card.className = 'book-card';
    const emoji = bookEmoji(book.title);
    card.innerHTML = `
      <button class="book-delete-btn" onclick="confirmDeleteBook(event, ${book.id})">✕</button>
      <div class="book-cover">${emoji}</div>
      <div class="book-card-title">${esc(book.title)}</div>
      <div class="book-card-meta">${formatSize(book.size)} · ${formatDate(book.addedAt)}</div>
      <div class="book-progress-bar">
        <div class="book-progress-fill" style="width:${book.progress || 0}%"></div>
      </div>`;
    card.onclick = (e) => {
      if (e.target.classList.contains('book-delete-btn')) return;
      openBook(book.id);
    };
    grid.appendChild(card);
  });
}

function bookEmoji(title) {
  const emojis = ['📖','📚','📜','🗒️','📕','📗','📘','📙'];
  let h = 0;
  for (const c of title) h = (h * 31 + c.charCodeAt(0)) & 0xffffff;
  return emojis[Math.abs(h) % emojis.length];
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + 'B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(0) + 'KB';
  return (bytes/1024/1024).toFixed(1) + 'MB';
}

function formatDate(ts) {
  const d = new Date(ts);
  return `${d.getMonth()+1}/${d.getDate()}`;
}

// ── FILE UPLOAD ──
function setupFileInput() {
  const input = document.getElementById('file-input');
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    input.value = '';

    showToast('載入中…');
    const text = await readFileText(file);
    const id = await saveBook(file.name.replace(/\.txt$/i,''), text, file.size);
    await renderLibrary();
    showToast('✅ 匯入成功');
    openBook(id);
  };
}

function readFileText(file) {
  return new Promise((resolve, reject) => {
    // Try UTF-8 first
    const r = new FileReader();
    r.onload = e => {
      let text = e.target.result;
      // Simple heuristic: if too many replacement chars, try GBK
      const repCount = (text.match(/\uFFFD/g)||[]).length;
      if (repCount > 50) {
        const r2 = new FileReader();
        r2.onload = e2 => resolve(e2.target.result);
        r2.onerror = () => resolve(text);
        r2.readAsText(file, 'GBK');
      } else {
        resolve(text);
      }
    };
    r.onerror = () => reject(r.error);
    r.readAsText(file, 'UTF-8');
  });
}

async function confirmDeleteBook(e, id) {
  e.stopPropagation();
  if (!confirm('確定要刪除這本書嗎？')) return;
  await deleteBook(id);
  await renderLibrary();
  showToast('已刪除');
}

// ── OPEN BOOK ──
async function openBook(id) {
  const book = await getBook(id);
  if (!book) return;

  App.currentBookId = id;
  App.rawText = book.content;
  App.isConverted = false;
  App.displayText = book.content;

  // Reset convert pill
  const pill = document.getElementById('convert-pill');
  pill.textContent = '繁→簡';
  pill.classList.remove('active');

  parseBook();
  renderReader();

  // Set title
  document.getElementById('reader-title').textContent = book.title;

  // Show reader page
  showPage('reader');

  // Restore scroll
  setTimeout(() => {
    const area = document.getElementById('reader-scroll');
    if (book.scrollPos) area.scrollTop = book.scrollPos;
  }, 100);
}

// ── PARSE BOOK ──
function parseBook() {
  const text = App.displayText;
  const lines = text.split('\n');
  const chReg = /^(第[零一二三四五六七八九十百千万萬\d]+[章节卷集回話话篇]+|Chapter\s*\d+|第\s*\d+\s*章|序章|前言|尾聲|後記|附錄|番外|楔子)/;
  
  App.chapters = [];
  App.paragraphs = [];
  let pIdx = 0;

  lines.forEach((line, lIdx) => {
    const t = line.trim();
    if (!t) return;
    if (chReg.test(t) && t.length < 60) {
      App.chapters.push({ title: t, paraIdx: pIdx, lineIdx: lIdx });
    } else {
      App.paragraphs.push(t);
      pIdx++;
    }
  });
}

// ── RENDER READER ──
function renderReader() {
  const text = App.displayText;
  const lines = text.split('\n');
  const chReg = /^(第[零一二三四五六七八九十百千万萬\d]+[章节卷集回話话篇]+|Chapter\s*\d+|第\s*\d+\s*章|序章|前言|尾聲|後記|附錄|番外|楔子)/;

  let html = '';
  let pIdx = 0;
  lines.forEach(line => {
    const t = line.trim();
    if (!t) return;
    if (chReg.test(t) && t.length < 60) {
      html += `<p class="ch-title">${esc(t)}</p>`;
    } else {
      html += `<p data-p="${pIdx}">${esc(t)}</p>`;
      pIdx++;
    }
  });

  document.getElementById('reader-content').innerHTML = html;
  applySettings();
  buildChapterList();
  renderBookmarks();
  updateProgress();
}

// ── CHAPTERS ──
function buildChapterList() {
  const list = document.getElementById('chapter-list');
  if (App.chapters.length === 0) {
    list.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-dim);font-size:13px">未偵測到章節標題</div>';
    return;
  }
  list.innerHTML = App.chapters.map((ch, i) =>
    `<div class="chapter-item" id="ch-${i}" onclick="jumpChapter(${i})">${esc(ch.title)}</div>`
  ).join('');
}

function jumpChapter(idx) {
  const ch = App.chapters[idx];
  // Find the paragraph element near this chapter
  const el = document.querySelector(`[data-p="${ch.paraIdx}"]`);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  document.querySelectorAll('.chapter-item').forEach(e => e.classList.remove('active'));
  const cel = document.getElementById('ch-' + idx);
  if (cel) cel.classList.add('active');
  closeDrawer('chapters-drawer');
}

// ── BOOKMARKS ──
async function addBookmark() {
  const area = document.getElementById('reader-scroll');
  const scrollPos = area.scrollTop;
  const total = area.scrollHeight - area.clientHeight;
  const progress = total > 0 ? Math.round(scrollPos / total * 100) : 0;

  // Get visible text preview
  const els = document.elementsFromPoint(
    window.innerWidth / 2, window.innerHeight / 2
  );
  const pEl = els.find(e => e.tagName === 'P' && e.dataset.p !== undefined);
  const preview = pEl ? pEl.textContent.substring(0, 20) + '…' : `${progress}%`;

  await addBookmark(App.currentBookId, scrollPos, progress, preview);
  renderBookmarks();
  showToast('🔖 已加入書籤');
}

async function renderBookmarks() {
  if (!App.currentBookId) return;
  const bms = await getBookmarks(App.currentBookId);
  const list = document.getElementById('bookmark-list');
  if (bms.length === 0) {
    list.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-dim);font-size:13px">尚無書籤</div>';
    return;
  }
  list.innerHTML = bms.map(bm => `
    <div class="bm-item">
      <div class="bm-info" onclick="jumpBookmark(${bm.scrollPos})">
        <div class="bm-preview">${esc(bm.preview)}</div>
        <div class="bm-meta">${bm.progress}% · ${new Date(bm.createdAt).toLocaleString('zh-TW',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}</div>
      </div>
      <button class="bm-del" onclick="removeBm(${bm.id})">🗑</button>
    </div>`).join('');
}

function jumpBookmark(scrollPos) {
  document.getElementById('reader-scroll').scrollTop = scrollPos;
  closeDrawer('bookmarks-drawer');
}

async function removeBm(id) {
  await deleteBookmark(id);
  renderBookmarks();
}

// ── PROGRESS ──
let progressTimer;
function updateProgress() {
  const area = document.getElementById('reader-scroll');
  if (!area) return;
  const scrollPos = area.scrollTop;
  const total = area.scrollHeight - area.clientHeight;
  const pct = total > 0 ? Math.round(scrollPos / total * 100) : 0;

  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-pct').textContent = pct + '%';

  clearTimeout(progressTimer);
  progressTimer = setTimeout(async () => {
    if (App.currentBookId) {
      await updateBookProgress(App.currentBookId, scrollPos, pct);
    }
  }, 800);
}

// ── TTS SETUP ──
function setupTTS() {
  TTS.setCallbacks(
    (idx) => {
      document.querySelectorAll('.tts-highlight').forEach(e => e.classList.remove('tts-highlight'));
      if (idx >= 0) {
        const el = document.querySelector(`[data-p="${idx}"]`);
        if (el) {
          el.classList.add('tts-highlight');
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          const ttsInfo = document.getElementById('tts-info');
          ttsInfo.textContent = el.textContent.substring(0, 30) + '…';
        }
      }
    },
    () => {
      document.getElementById('tts-play').textContent = '▶';
      document.getElementById('tts-info').textContent = '朗讀完畢';
    },
    (idx, total) => {}
  );
}

function toggleTTS() {
  if (!App.paragraphs.length) return;
  if (TTS.isActive()) {
    TTS.pause();
    document.getElementById('tts-play').textContent = '▶';
  } else {
    TTS.setParagraphs(App.paragraphs);
    TTS.play();
    document.getElementById('tts-play').textContent = '⏸';
  }
}

function ttsSpeed() {
  const s = TTS.cycleSpeed();
  document.getElementById('tts-speed').textContent = s + '×';
}

// ── CONVERT ──
function toggleConvert() {
  const pill = document.getElementById('convert-pill');
  App.isConverted = !App.isConverted;

  const scrollPos = document.getElementById('reader-scroll').scrollTop;

  if (App.isConverted) {
    App.displayText = toSimplified(App.rawText);
    pill.textContent = '簡→繁';
    pill.classList.add('active');
  } else {
    App.displayText = App.rawText;
    pill.textContent = '繁→簡';
    pill.classList.remove('active');
  }

  parseBook();
  renderReader();
  setTimeout(() => {
    document.getElementById('reader-scroll').scrollTop = scrollPos;
  }, 50);
}

// ── SETTINGS UI ──
function changeFontSize(delta) {
  App.settings.fontSize = Math.max(12, Math.min(30, App.settings.fontSize + delta));
  document.getElementById('font-size-val').textContent = App.settings.fontSize;
  document.getElementById('reader-content').style.fontSize = App.settings.fontSize + 'px';
  persistSettings();
}

function setTheme(theme) {
  App.settings.theme = theme;
  document.body.setAttribute('data-theme', theme);
  document.querySelectorAll('[data-theme-btn]').forEach(b =>
    b.classList.toggle('active', b.dataset.themeBtn === theme));
  persistSettings();
}

function setFont(font) {
  App.settings.font = font;
  document.getElementById('reader-content').style.fontFamily =
    font === 'sans' ? "'Noto Sans TC', sans-serif" : "'Noto Serif TC', serif";
  document.querySelectorAll('[data-font-btn]').forEach(b =>
    b.classList.toggle('active', b.dataset.fontBtn === font));
  persistSettings();
}

function setLineHeight(val) {
  App.settings.lineHeight = parseFloat(val);
  document.getElementById('reader-content').style.lineHeight = val;
  persistSettings();
}

// ── PAGE NAV ──
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('hidden', 'slide-left');
  });
  if (name === 'reader') {
    document.getElementById('page-library').classList.add('slide-left');
    setupTTS();
  } else {
    TTS.stop();
    document.getElementById('tts-play').textContent = '▶';
    document.getElementById('page-reader').classList.add('hidden');
  }
}

// ── DRAWERS ──
function openDrawer(id) {
  document.getElementById(id).classList.add('open');
  document.getElementById('drawer-overlay').classList.add('open');
}
function closeDrawer(id) {
  document.getElementById(id).classList.remove('open');
  document.getElementById('drawer-overlay').classList.remove('open');
}
function closeAllDrawers() {
  document.querySelectorAll('.drawer').forEach(d => d.classList.remove('open'));
  document.getElementById('drawer-overlay').classList.remove('open');
}

// ── UI TOGGLE (tap to hide/show nav) ──
let uiVisible = true;
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('reader-scroll').addEventListener('click', (e) => {
    if (e.target.tagName === 'P') {
      uiVisible = !uiVisible;
      document.querySelector('.reader-nav').classList.toggle('hidden-ui', !uiVisible);
      document.querySelector('.reader-bottom').classList.toggle('hidden-ui', !uiVisible);
    }
  });
});

// ── UTILS ──
function esc(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2000);
}

// ── START ──
document.addEventListener('DOMContentLoaded', init);
