// db.js — IndexedDB wrapper for 書卷
const DB_NAME = 'ShujuanDB';
const DB_VER = 1;
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    if (db) return resolve(db);
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = e => {
      const d = e.target.result;
      if (!d.objectStoreNames.contains('books')) {
        const books = d.createObjectStore('books', { keyPath: 'id', autoIncrement: true });
        books.createIndex('title', 'title', { unique: false });
      }
      if (!d.objectStoreNames.contains('settings')) {
        d.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!d.objectStoreNames.contains('bookmarks')) {
        const bm = d.createObjectStore('bookmarks', { keyPath: 'id', autoIncrement: true });
        bm.createIndex('bookId', 'bookId', { unique: false });
      }
    };
    req.onsuccess = e => { db = e.target.result; resolve(db); };
    req.onerror = () => reject(req.error);
  });
}

// Books
async function saveBook(title, content, size) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('books', 'readwrite');
    const store = tx.objectStore('books');
    const req = store.add({
      title, content, size,
      addedAt: Date.now(),
      progress: 0,
      scrollPos: 0
    });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getAllBooks() {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('books', 'readonly');
    const req = tx.objectStore('books').getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getBook(id) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('books', 'readonly');
    const req = tx.objectStore('books').get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function updateBookProgress(id, scrollPos, progress) {
  const d = await openDB();
  return new Promise(async (resolve, reject) => {
    const book = await getBook(id);
    if (!book) return reject('Book not found');
    book.scrollPos = scrollPos;
    book.progress = progress;
    const tx = d.transaction('books', 'readwrite');
    const req = tx.objectStore('books').put(book);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function deleteBook(id) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('books', 'readwrite');
    const req = tx.objectStore('books').delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Settings
async function saveSetting(key, value) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('settings', 'readwrite');
    const req = tx.objectStore('settings').put({ key, value });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function getSetting(key, defaultVal = null) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('settings', 'readonly');
    const req = tx.objectStore('settings').get(key);
    req.onsuccess = () => resolve(req.result ? req.result.value : defaultVal);
    req.onerror = () => reject(req.error);
  });
}

// Bookmarks
async function addBookmark(bookId, scrollPos, progress, preview) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('bookmarks', 'readwrite');
    const req = tx.objectStore('bookmarks').add({
      bookId, scrollPos, progress, preview,
      createdAt: Date.now()
    });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function getBookmarks(bookId) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('bookmarks', 'readonly');
    const idx = tx.objectStore('bookmarks').index('bookId');
    const req = idx.getAll(bookId);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function deleteBookmark(id) {
  const d = await openDB();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('bookmarks', 'readwrite');
    const req = tx.objectStore('bookmarks').delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
