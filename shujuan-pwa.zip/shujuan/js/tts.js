// tts.js — 聽書模組
const TTS = (() => {
  const synth = window.speechSynthesis;
  const SPEEDS = [0.7, 1.0, 1.25, 1.5, 1.75, 2.0];
  let speedIdx = 1;
  let active = false;
  let paraIdx = 0;
  let paragraphs = [];
  let onHighlight = null;
  let onEnd = null;
  let onProgress = null;

  function setParagraphs(paras) { paragraphs = paras; }
  function setCallbacks(highlight, end, progress) {
    onHighlight = highlight;
    onEnd = end;
    onProgress = progress;
  }

  function speak(idx) {
    if (idx >= paragraphs.length) { stop(); onEnd && onEnd(); return; }
    synth.cancel();
    paraIdx = idx;
    active = true;

    onHighlight && onHighlight(idx);
    onProgress && onProgress(idx, paragraphs.length);

    const u = new SpeechSynthesisUtterance(paragraphs[idx]);
    u.lang = 'zh-TW';
    u.rate = SPEEDS[speedIdx];

    // Pick best Chinese voice
    const voices = synth.getVoices();
    const zhVoice = voices.find(v => v.lang.startsWith('zh') && v.localService) ||
                    voices.find(v => v.lang.startsWith('zh'));
    if (zhVoice) u.voice = zhVoice;

    u.onend = () => { if (active) speak(idx + 1); };
    u.onerror = () => { if (active) speak(idx + 1); };
    synth.speak(u);
  }

  function play(fromIdx) {
    speak(fromIdx !== undefined ? fromIdx : paraIdx);
  }

  function pause() {
    active = false;
    synth.cancel();
    onHighlight && onHighlight(-1);
  }

  function stop() {
    active = false;
    paraIdx = 0;
    synth.cancel();
    onHighlight && onHighlight(-1);
  }

  function prev() {
    const idx = Math.max(0, paraIdx - 1);
    if (active) speak(idx); else paraIdx = idx;
  }

  function next() {
    if (active) speak(paraIdx + 1); else paraIdx++;
  }

  function cycleSpeed() {
    speedIdx = (speedIdx + 1) % SPEEDS.length;
    if (active) speak(paraIdx);
    return SPEEDS[speedIdx];
  }

  function isActive() { return active; }
  function currentIdx() { return paraIdx; }
  function currentSpeed() { return SPEEDS[speedIdx]; }

  return { setParagraphs, setCallbacks, play, pause, stop, prev, next, cycleSpeed, isActive, currentIdx, currentSpeed };
})();
