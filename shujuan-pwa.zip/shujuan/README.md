# 書卷 · TXT 閱讀器 PWA

一個可安裝到 iPhone 主畫面的 TXT 小說閱讀器。

## 功能
- 📚 書庫管理（多本書，永久儲存）
- 📖 自動章節偵測與目錄
- 🔊 聽書（TTS 朗讀，速度可調）
- 🔄 繁簡體中文相互轉換
- 🌙 日間 / 夜間 / 護眼 主題
- 🔖 書籤功能
- 📱 iPhone 全螢幕 PWA

## 部署到 GitHub Pages（免費）

1. 登入 [github.com](https://github.com)
2. 點右上角 **+** → **New repository**
3. Repository name 填：`shujuan`
4. 選 **Public** → 點 **Create repository**
5. 點 **uploading an existing file**
6. 把這個資料夾內所有檔案拖曳上傳
7. 點 **Commit changes**
8. 進入 **Settings** → **Pages** → Source 選 **main** branch → **Save**
9. 等 1~2 分鐘，你的網址會是：
   `https://你的GitHub帳號.github.io/shujuan/`

## iPhone 安裝方式

1. 用 **Safari** 開啟上面的網址
2. 點下方 **分享按鈕**（方框加箭頭）
3. 選「**加入主畫面**」
4. 點「**新增**」
5. 完成！桌面會出現「書卷」App 圖示
